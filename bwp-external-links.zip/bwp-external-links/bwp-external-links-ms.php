<?php
include_once dirname(__FILE__) . '/bwp-external-links/bwp-external-links.php';
